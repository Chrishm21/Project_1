//
//  ThirdViewController.swift
//  Carrito
//
//  Created by Macbook on 08/10/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
class ThirdViewController: UIViewController {
    
    
    
    @IBOutlet weak var valor: UILabel!
    var dataFromFirstView : Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        valor.text = String(dataFromFirstView)
        
    }
}
